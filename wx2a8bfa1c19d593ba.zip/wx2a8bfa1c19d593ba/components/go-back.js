var e = require("../common/vendor.js"),
  t = require("../common/assets.js"),
  s = {
    name: "go-back",
    props: {
      type: {
        type: String,
        default: "_"
      },
      isKeepOn: {
        type: Boolean,
        default: !1
      }
    },
    data: function data() {
      return {
        isShowBtn: !0,
        isSleep: !1
      };
    },
    methods: {
      setKeepScreenOn: function setKeepScreenOn() {
        this.isKeepOn = !this.isKeepOn, this.isShowBtn = !this.isShowBtn, e.index.setKeepScreenOn({
          keepScreenOn: this.isKeepOn
        }), e.index.showToast({
          title: this.isKeepOn ? "开启屏幕常亮" : "关闭屏幕常亮",
          icon: this.isKeepOn ? "success" : "error"
        });
      },
      setSleepTime: function setSleepTime() {
        clearTimeout(this.timer), this.isSleep = !this.isSleep;
      },
      goBack: function goBack() {
        e.index.navigateBack();
      },
      _showButton: function _showButton() {
        var _this = this;
        this.isShowBtn = !this.isShowBtn, clearTimeout(this.timer), this.isShowBtn && (this.timer = setTimeout(function () {
          return _this.isShowBtn = !1;
        }, 3500));
      },
      _setKeepScreenOn: function _setKeepScreenOn() {
        var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !0;
        t && e.index.showToast({
          title: "已开启常亮",
          icon: "none"
        }), e.index.setKeepScreenOn({
          keepScreenOn: t
        });
      }
    }
  };var i = e._export_sfc(s, [["render", function (s, i, n, o, p, r) {
  return e.e({
    a: t._imports_0$3,
    b: e.o(function () {
      return r.goBack && r.goBack.apply(r, arguments);
    }),
    c: "star" === n.type
  }, "star" === n.type ? {
    d: t._imports_1$1,
    e: n.isKeepOn ? 1 : "",
    f: e.o(function () {
      return r.setKeepScreenOn && r.setKeepScreenOn.apply(r, arguments);
    })
  } : "clock" == n.type ? {
    h: t._imports_2$1,
    i: p.isSleep ? 1 : "",
    j: e.o(function () {
      return r.setSleepTime && r.setSleepTime.apply(r, arguments);
    })
  } : {}, {
    g: "clock" == n.type,
    k: p.isShowBtn ? 1 : ""
  });
}], ["__scopeId", "data-v-ec959226"]]);wx.createComponent(i);