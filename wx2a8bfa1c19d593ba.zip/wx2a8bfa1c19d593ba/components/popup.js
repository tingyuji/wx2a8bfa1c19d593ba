var o = require("../common/vendor.js"),
  s = {
    name: "popup",
    props: {
      isSlot: {
        type: Boolean,
        default: !1
      }
    },
    data: function data() {
      return {
        isShow: !1
      };
    },
    methods: {
      onPopup: function onPopup() {
        this.isShow = !this.isShow;
      },
      _closePopup: function _closePopup() {
        this.isSlot || this.onPopup();
      }
    }
  };var e = o._export_sfc(s, [["render", function (s, e, t, p, i, n) {
  return o.e({
    a: t.isSlot
  }, (t.isSlot, {}), {
    b: i.isShow,
    c: o.o(function () {
      return n._closePopup && n._closePopup.apply(n, arguments);
    })
  });
}], ["__scopeId", "data-v-781e7e16"]]);wx.createComponent(e);