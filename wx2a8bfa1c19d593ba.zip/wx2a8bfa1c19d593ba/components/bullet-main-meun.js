var e = require("../common/vendor.js"),
  t = require("../api/v1/index.js"),
  s = require("../utils/check.js"),
  n = require("../common/assets.js"),
  i = {
    name: "bullet-main-meun",
    data: function data() {
      return {
        cacheKey: "MAIN_MEUN",
        animationText: {},
        userInput: "",
        usefulText: [],
        phrases: ""
      };
    },
    created: function created() {
      this.usefulText = e.index.getStorageSync(this.cacheKey) || ["小姐姐加个微信可以吗？", "能加个微信吗？", "我喜欢你！", "单身可撩！", "点击空白处可全屏"], this.animation = e.index.createAnimation({
        timingFunction: "linear",
        duration: 300
      }), this.autoCloseMainMeun();
    },
    methods: {
      mainMeunClick: function mainMeunClick() {
        var _this = this;
        e.index.createSelectorQuery().in(this).select(".footer").boundingClientRect(function (e) {
          var t = _this.hideMenu ? 0 : e.height;
          _this.animation.translateY(t).step(), _this.hideMenu = !_this.hideMenu, _this.animationText = _this.animation.export(), _this.autoCloseMainMeun();
        }).exec();
      },
      autoCloseMainMeun: function autoCloseMainMeun() {
        var _this2 = this;
        clearTimeout(this.mainMeunTimer), this.hideMenu || this.clearTextOff || (this.mainMeunTimer = setTimeout(function () {
          _this2.mainMeunClick();
        }, 5e3));
      },
      cursorInput: function cursorInput() {
        this.clearTextOff = !this.clearTextOff, this.autoCloseMainMeun();
      },
      inputTextConfirm: function inputTextConfirm() {
        var _this3 = this;
        var e = this.userInput.trim();
        this.check(e, function () {
          _this3.$emit("sendEvent", e);
        }), this.userInput = "";
      },
      clearInputText: function clearInputText() {
        this.userInput = "";
      },
      onStyleDrawer: function onStyleDrawer() {
        this.mainMeunClick(), this.$emit("openStyleEvent");
      },
      goBack: function goBack() {
        e.index.navigateBack();
      },
      sendTextFunc: function sendTextFunc(e) {
        var t = this.usefulText[e];
        this.$emit("sendEvent", t);
      },
      clearTextFunc: function clearTextFunc(t) {
        this.usefulText.splice(t, 1), e.index.setStorageSync(this.cacheKey, this.usefulText);
      },
      openPopup: function openPopup() {
        this.cursorInput(), this.$refs.pop.onPopup();
      },
      closePopup: function closePopup() {
        this.cursorInput(), this.$refs.pop.onPopup();
      },
      savePhrases: function savePhrases() {
        var _this4 = this;
        this.cursorInput(), this.$refs.pop.onPopup();
        var t = this.phrases.trim();
        this.check(t, function () {
          _this4.usefulText.unshift(t);
        }), this.phrases = "", e.index.setStorageSync(this.cacheKey, this.usefulText);
      },
      check: function check(n, i) {
        e.index.showLoading({
          title: "加载中"
        }), t.checkContent(n).then(function (t) {
          var _t$result = t.result,
            n = _t$result.label,
            o = _t$result.sign,
            u = _t$result.msg,
            r = _t$result.time;
          s.checkSign(r, o) && 100 == n ? i() : e.index.showToast({
            title: 100 == n ? "文本不合法" : "\u6587\u672C\u5305\u542B ".concat(u),
            icon: "error",
            duration: 2e3
          }), e.index.hideLoading();
        });
      }
    },
    components: {
      popup: function popup() {
        return "./popup.js";
      }
    }
  };if (!Array) {
  e.resolveComponent("popup")();
}var o = e._export_sfc(i, [["render", function (t, s, i, o, u, r) {
  return e.e({
    a: e.o(function () {
      return r.goBack && r.goBack.apply(r, arguments);
    }),
    b: n._imports_0$2,
    c: e.o(function () {
      return r.cursorInput && r.cursorInput.apply(r, arguments);
    }),
    d: e.o(function () {
      return r.cursorInput && r.cursorInput.apply(r, arguments);
    }),
    e: e.o(function () {
      return r.inputTextConfirm && r.inputTextConfirm.apply(r, arguments);
    }),
    f: u.userInput,
    g: e.o(function (e) {
      return u.userInput = e.detail.value;
    }),
    h: u.userInput
  }, u.userInput ? {
    i: n._imports_1,
    j: e.o(function () {
      return r.clearInputText && r.clearInputText.apply(r, arguments);
    })
  } : {}, {
    k: e.o(function () {
      return r.onStyleDrawer && r.onStyleDrawer.apply(r, arguments);
    }),
    l: n._imports_2,
    m: e.o(function (e) {
      return r.openPopup();
    }),
    n: u.usefulText.length > 0
  }, u.usefulText.length > 0 ? {
    o: e.f(u.usefulText, function (t, s, n) {
      return {
        a: e.t(t),
        b: e.o(function (e) {
          return r.sendTextFunc(s);
        }, s),
        c: e.o(function (e) {
          return r.clearTextFunc(s);
        }, s),
        d: s
      };
    }),
    p: n._imports_1
  } : {}, {
    q: e.o(function () {
      return r.autoCloseMainMeun && r.autoCloseMainMeun.apply(r, arguments);
    }),
    r: u.animationText,
    s: u.phrases,
    t: e.o(function (e) {
      return u.phrases = e.detail.value;
    }),
    v: e.o(function () {
      return r.closePopup && r.closePopup.apply(r, arguments);
    }),
    w: e.o(function () {
      return r.savePhrases && r.savePhrases.apply(r, arguments);
    }),
    x: e.sr("pop", "50c001be-0"),
    y: e.p({
      isSlot: !0
    })
  });
}], ["__scopeId", "data-v-50c001be"]]);wx.createComponent(o);