var _toConsumableArray2 = require("../@babel/runtime/helpers/toConsumableArray");require("../@babel/runtime/helpers/Arrayincludes");var e = require("../common/vendor.js"),
  t = {
    name: "flip-clock",
    props: {
      theme: {
        type: String,
        default: "index-theme",
        validator: function validator(e) {
          return ["index-theme", "clock-theme"].includes(e);
        }
      }
    },
    data: function data() {
      return {
        date: "",
        timeStr: "",
        timeRunner: ""
      };
    },
    computed: {
      timeArr: function timeArr() {
        return _toConsumableArray2(this.timeStr).map(function (e, t) {
          var r;
          return !0 & t ? r = 9 : 0 == t ? r = 2 : (2 == t || 4 == t) && (r = 5), {
            max: r,
            current: Number(e)
          };
        });
      },
      lunar: function lunar() {
        var t = new Date(),
          r = t.getFullYear(),
          a = t.getMonth() + 1,
          n = t.getDate(),
          _e$lunar_calendar$get = e.lunar_calendar.getLunar(r, a, n),
          m = _e$lunar_calendar$get.lunarYear,
          i = _e$lunar_calendar$get.dateStr,
          c = _e$lunar_calendar$get.zodiac;
        return "".concat(m, " ").concat(i, " ").concat(c);
      }
    },
    methods: {
      getTimeStr: function getTimeStr() {
        var t = "index-theme" === this.theme ? "HHmm" : "HHmmss";
        return e.dayjs().format(t);
      },
      setDate: function setDate() {
        var t = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"][e.dayjs().day()],
          r = "index-theme" === this.theme ? "MM月DD日" : "YYYY年MM月DD日";
        this.date = "".concat(e.dayjs().format(r), " ").concat(t), this.timeStr = this.getTimeStr();
      },
      updata: function updata() {
        var _this = this;
        this.timeRunner = setInterval(function () {
          _this.timeStr = _this.getTimeStr();
        }, 1e3);
      },
      updataOnce: function updataOnce() {
        this.timeStr = this.getTimeStr();
      },
      clearUpdata: function clearUpdata() {
        clearInterval(this.timeRunner);
      }
    },
    created: function created() {
      this.setDate();
    }
  };var r = e._export_sfc(t, [["render", function (t, r, a, n, m, i) {
  return e.e({
    a: e.t(m.date),
    b: "clock-theme" === a.theme
  }, "clock-theme" === a.theme ? {
    c: e.t(i.lunar)
  } : {}, {
    d: e.n(a.theme),
    e: e.f(i.timeArr, function (t, r, a) {
      return {
        a: e.f(t.max + 1, function (r, a, n) {
          return {
            a: e.t(a),
            b: e.t(a),
            c: a,
            d: t.current == a ? 1 : "",
            e: t.current - 1 == a || a == t.max && 0 == t.current ? 1 : ""
          };
        }),
        b: r
      };
    }),
    f: e.n(a.theme)
  });
}], ["__scopeId", "data-v-ececb754"]]);wx.createComponent(r);