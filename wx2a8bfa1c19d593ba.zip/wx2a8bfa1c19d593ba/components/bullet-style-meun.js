require("../@babel/runtime/helpers/Arrayincludes");var t = require("../common/vendor.js"),
  e = {
    name: "bullet-style-meun",
    props: ["color", "fontFamily", "speed", "fontSize", "classNames", "background"],
    data: function data() {
      return {
        animationStyle: {},
        colorStyles: ["white", "black", "#ff0071", "#ff000c", "#ff5300", "#ffe200", "#00ff27", "#009fff", "#00ffc8", "#8500ff"],
        fontStyle: [{
          name: "PingFang SC",
          value: "font0.png",
          title: "默认"
        }, {
          name: "Epson",
          value: "font1.png",
          title: "打字机(仅英文生效)"
        }, {
          name: "Huakang",
          value: "font2.png",
          title: "华康少女"
        }, {
          name: "HappyZcool-2016",
          value: "font3.png",
          title: "站酷快乐"
        }, {
          name: "PangMenZhengDao",
          value: "font4.png",
          title: "庞门正道"
        }],
        textStyle: [{
          name: "flicker",
          title: "闪烁"
        }, {
          name: "border",
          title: "描边"
        }, {
          name: "textShadow",
          title: "阴影"
        }, {
          name: "light",
          title: "高亮"
        }, {
          name: "text3D",
          title: "3D"
        }, {
          name: "douyin",
          title: "抖音"
        }],
        speedScale: ["0.5X", "1X", "1.5X", "2X", "2.5X"],
        fontSizeScale: [20, 25, 30, 35, 40],
        fontTitle: "",
        show_ft: !1,
        styleTitle: "",
        show_st: !1
      };
    },
    created: function created() {
      this.animation = t.index.createAnimation({
        timingFunction: "linear"
      });
    },
    methods: {
      styleMeunClick: function styleMeunClick() {
        var _this = this;
        var e = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !0;
        (this.openMeun || e) && (this.openMeun = e, t.index.createSelectorQuery().in(this).select(".textStyle").boundingClientRect(function (t) {
          var n = e ? 0 : t.height;
          _this.animation.translateY(n).step(), _this.animationStyle = _this.animation.export();
        }).exec());
      },
      setTextStyle: function setTextStyle(e, n, o) {
        var _this2 = this;
        if (["speed", "fontSize"].includes(e) && (n = n.detail.value), "color" == e || "background" == e) {
          if (this["color" === e ? "background" : "color"] == n) return void t.index.showToast({
            title: "文字与背景的颜色不能一样",
            icon: "none"
          });
        }
        "fontFamily" == e && (this.fontTitle = o, this.show_ft = !1, setTimeout(function () {
          _this2.show_ft = !0;
        }, 60)), this.$emit("textStyle", e, n);
      },
      effectControl: function effectControl(t, e) {
        var _this3 = this;
        var n = this.classNames;
        this.classNames.includes(t) ? n = this.classNames.filter(function (e) {
          return e !== t;
        }) : (n.push(t), this.styleTitle = e, this.show_st = !1, setTimeout(function () {
          _this3.show_st = !0;
        })), this.$emit("textStyle", "classNames", n);
      }
    }
  };var n = t._export_sfc(e, [["render", function (e, n, o, l, i, a) {
  return {
    a: t.f(i.colorStyles, function (e, n, l) {
      return {
        a: e == o.color ? 1 : "",
        b: n,
        c: t.o(function (t) {
          return a.setTextStyle("color", e);
        }, n),
        d: e
      };
    }),
    b: t.t(i.fontTitle),
    c: i.show_ft ? 1 : "",
    d: t.f(i.fontStyle, function (e, n, l) {
      return {
        a: t.o(function (t) {
          return a.setTextStyle("fontFamily", e.name, e.title);
        }, n),
        b: "/static/bulletScree/" + e.value,
        c: e.name == o.fontFamily ? 1 : "",
        d: n
      };
    }),
    e: t.o(function (t) {
      return a.setTextStyle("speed", t);
    }),
    f: o.speed,
    g: t.f(i.speedScale, function (e, n, o) {
      return {
        a: t.t(e),
        b: n
      };
    }),
    h: t.o(function (t) {
      return a.setTextStyle("fontSize", t);
    }),
    i: o.fontSize,
    j: t.f(i.fontSizeScale, function (e, n, o) {
      return {
        a: t.t(e),
        b: n
      };
    }),
    k: t.t(i.styleTitle),
    l: i.show_st ? 1 : "",
    m: t.f(i.textStyle, function (e, n, l) {
      return {
        a: t.o(function (t) {
          return a.effectControl(e.name, e.title);
        }, n),
        b: "/static/bulletScree/" + e.name + ".png",
        c: o.classNames.includes(e.name) ? 1 : "",
        d: n
      };
    }),
    n: t.f(i.colorStyles, function (e, n, l) {
      return {
        a: e == o.background ? 1 : "",
        b: t.o(function (t) {
          return a.setTextStyle("background", e);
        }, n),
        c: e,
        d: n
      };
    }),
    o: i.animationStyle
  };
}], ["__scopeId", "data-v-1beff893"]]);wx.createComponent(n);