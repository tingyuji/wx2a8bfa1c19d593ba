var t = require("../common/vendor.js"),
  a = {
    name: "top-nav",
    props: {
      title: {
        type: String,
        default: "掌机工具"
      }
    },
    data: function data() {
      return {
        backgroundImage: "../static/bg/3.jpg",
        navBarInfo: {},
        top: 0,
        navBarHeight: 0
      };
    },
    created: function created() {
      var _this$$appSystemInfo = this.$appSystemInfo,
        t = _this$$appSystemInfo.navBarInfo,
        a = _this$$appSystemInfo.navBarBoundingInfo;
      this.navBarHeight = t.height, this.top = a.top + 5;
    },
    methods: {}
  };var n = t._export_sfc(a, [["render", function (a, n, e, o, r, i) {
  return {
    a: r.navBarHeight + "px",
    b: t.t(e.title),
    c: r.top + "px",
    d: r.backgroundImage,
    e: r.navBarHeight + "px",
    f: r.backgroundImage
  };
}]]);wx.createComponent(n);