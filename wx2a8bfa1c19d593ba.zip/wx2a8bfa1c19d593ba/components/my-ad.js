var e = require("../common/vendor.js"),
  r = {
    name: "my-ad",
    data: function data() {
      return {
        adStyleO: {
          borderRadius: "30rpx !important",
          overflow: "hidden",
          boxShadow: "0 0 10rpx 5rpx rgba(0, 0, 0, .1)"
        }
      };
    }
  };var o = e._export_sfc(r, [["render", function (r, o, a, t, d, n) {
  return {
    a: e.s(d.adStyleO)
  };
}], ["__scopeId", "data-v-a8d4f192"]]);wx.createComponent(o);