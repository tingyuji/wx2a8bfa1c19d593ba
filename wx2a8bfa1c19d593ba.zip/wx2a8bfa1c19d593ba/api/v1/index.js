var e = require("../../utils/request.js");exports.checkContent = function (t) {
  return e.request("/auth/checkContent", "POST", {
    content: t
  }, !0);
}, exports.loginApi = function (t) {
  return e.request("/auth/login", "GET", {
    code: t
  }, !1);
};