var _regeneratorRuntime2 = require("@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("@babel/runtime/helpers/asyncToGenerator");Object.defineProperty(exports, Symbol.toStringTag, {
  value: "Module"
});var o = require("./common/vendor.js"),
  t = require("./utils/login.js"),
  n = require("./utils/hooks/uni-system-info.js");Math;var a = {
  globalData: {},
  onLaunch: function onLaunch() {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return t.login();
          case 2:
            _this.loadFontFace();
          case 3:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  onShow: function onShow() {},
  onHide: function onHide() {},
  methods: {
    loadFontFace: function loadFontFace() {
      var t = [{
        name: "Epson",
        url: "https://alist.mortal-web.top/d/miniprogram/font/epson.ttf?sign=xNWf7g7o0nojWuff622q3mOqqLpiDFV7yBR0N7cI2qo=:0"
      }, {
        name: "Huakang",
        url: "https://alist.mortal-web.top/d/miniprogram/font/Huakang.ttf?sign=x2_5jbpAa-mLAYSBrzVB-6UpYx9t06s8yFxybGrb8yE=:0"
      }, {
        name: "HappyZcool-2016",
        url: "https://alist.mortal-web.top/d/miniprogram/font/HappyZcool_2016.ttf?sign=SWh50RvYF_PZ5GX42VCyCA9YB0gozczsnWuuz7Wha6g=:0"
      }, {
        name: "PangMenZhengDao",
        url: "https://alist.mortal-web.top/d/miniprogram/font/PangMenZhengDao.ttf?sign=DWZfrNTCytO7gqXWw3Cgo2RGIzRfhW-OrYGjHr85k6w=:0"
      }];
      for (var _i = 0, _t = t; _i < _t.length; _i++) {
        var _n = _t[_i];
        o.index.loadFontFace({
          family: _n.name,
          source: "url(\"".concat(_n.url, "\")"),
          global: !0,
          fail: function fail(o) {
            console.log(o.status);
          }
        });
      }
    }
  }
};function e() {
  var t = o.createSSRApp(a);
  return t.config.globalProperties.$appSystemInfo = n.uniSystemInfo(), {
    app: t
  };
}e().app.mount("#app"), exports.createApp = e;