var e = require("../../common/vendor.js"),
  o = require("../../utils/advertisement.js"),
  n = {
    data: function data() {
      return {
        list: [{
          title: "推荐",
          icon: "hot.png",
          items: [{
            name: "手持弹幕",
            desc: "表白、搭讪、接机、演唱会，适用各种场合",
            page: "bulletScree",
            icon: "video.png",
            label: "精美",
            color: "#6A52EF"
          }]
        }, {
          title: "精品",
          icon: "hot.png",
          items: [{
            name: "满屏国旗",
            desc: "我爱你，祖国！",
            page: "star",
            icon: "china.png",
            label: "精美",
            color: "#C62A31"
          }, {
            name: "翻页时钟",
            desc: "very nice!",
            page: "clock",
            icon: "midnight.png",
            label: "精品",
            color: "#3A7CDB"
          }, {
            name: "氛围灯-闪屏",
            desc: "举起你们的双手一起摇起来~",
            page: "splashScreen",
            icon: "flash.png",
            label: "精美",
            color: "#9739E9"
          }]
        }, {
          title: "实用工具",
          icon: "hot.png",
          items: [{
            name: "量角器",
            desc: "角度测量，实用工具",
            page: "protractor",
            icon: "protractor.png",
            label: "实用",
            color: "#EE8332"
          }, {
            name: "直尺",
            desc: "随身携带的尺子，太方便了！",
            page: "ruler",
            icon: "ruler.png",
            label: "实用",
            color: "#EE8332"
          }]
        }]
      };
    },
    onLoad: function onLoad() {
      o.interstitial.load();
    },
    onShow: function onShow() {
      this.$refs.flipClock.updataOnce();
    },
    onReady: function onReady() {
      o.interstitial.show();
    },
    methods: {
      goPage: function goPage(o) {
        var n = "/pages/".concat(o, "/").concat(o);
        e.index.navigateTo({
          url: n
        });
      }
    },
    components: {
      topNav: function topNav() {
        return "../../components/top-nav.js";
      },
      flipClock: function flipClock() {
        return "../../components/flip-clock.js";
      },
      myAd: function myAd() {
        return "../../components/my-ad.js";
      }
    },
    onShareAppMessage: function onShareAppMessage() {
      return {
        title: "掌机工具箱",
        path: "/pages/index/index"
      };
    },
    onShareTimeline: function onShareTimeline() {}
  };if (!Array) {
  (e.resolveComponent("top-nav") + e.resolveComponent("flip-clock") + e.resolveComponent("my-ad"))();
}var t = e._export_sfc(n, [["render", function (o, n, t, a, c, i) {
  return {
    a: e.sr("flipClock", "fe359e43-1"),
    b: e.f(c.list, function (o, n, t) {
      return {
        a: "/static/index/" + o.icon,
        b: e.t(o.title),
        c: e.f(o.items, function (o, n, t) {
          return {
            a: e.t(o.name),
            b: e.t(o.desc),
            c: "/static/index/" + o.icon,
            d: e.t(o.label),
            e: o.color,
            f: e.o(function (e) {
              return i.goPage(o.page);
            }, n),
            g: n
          };
        }),
        d: n
      };
    })
  };
}], ["__scopeId", "data-v-fe359e43"]]);n.__runtimeHooks = 6, wx.createPage(t);