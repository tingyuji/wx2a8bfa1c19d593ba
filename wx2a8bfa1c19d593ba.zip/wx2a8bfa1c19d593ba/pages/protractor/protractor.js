var _defineProperty2 = require("../../@babel/runtime/helpers/defineProperty");var t = require("../../common/vendor.js"),
  e = {
    data: function data() {
      return {
        win: {},
        angle: 90,
        isOpenCamera: !1,
        isLock: !1,
        src: "",
        canvasStyle: {
          width: "100%",
          height: "100%"
        }
      };
    },
    computed: {
      openCameraStr: function openCameraStr() {
        return this.isOpenCamera && !this.isLock ? "关摄像头" : this.isLock ? "复位" : "开摄像头";
      },
      bgSrc: function bgSrc() {
        return this.src ? this.src : "../../static/bg/ruler.jpg";
      }
    },
    onLoad: function onLoad() {
      var _this$$appSystemInfo$ = this.$appSystemInfo.screenInfo,
        e = _this$$appSystemInfo$.windowHeight,
        a = _this$$appSystemInfo$.windowWidth,
        i = _this$$appSystemInfo$.pixelRatio;
      this.win = {
        windowWidth: a,
        windowHeight: e,
        pixelRatio: i
      }, this.photoCtx = t.index.createCameraContext();
    },
    mounted: function mounted() {
      t.index.createSelectorQuery().select("#protractor").fields({
        node: !0,
        size: !0
      }).exec(this.init.bind(this, !1)), t.index.createSelectorQuery().select("#rocker").fields({
        node: !0,
        size: !0
      }).exec(this.init.bind(this, !0));
    },
    methods: _defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2({
      init: function init() {
        var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !1;
        var e = arguments.length > 1 ? arguments[1] : undefined;
        var _e$ = e[0],
          a = _e$.width,
          i = _e$.height,
          o = _e$.node,
          s = o.getContext("2d"),
          h = this.win.pixelRatio;
        o.width = a * h, o.height = i * h, t ? (this.canvas = o, this.ctx = s, this.drawRocker()) : this.drawProtractor(s, o);
      },
      drawRocker: function drawRocker() {
        var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 90;
        var e = this.win.pixelRatio,
          a = this.canvas,
          i = this.ctx;
        i.clearRect(0, 0, a.width, a.height), i.translate(.39 * a.width, .45 * a.height), i.rotate(Math.PI / 2), i.font = 32 * e + "px Arial", i.fillStyle = "#000", i.textAlign = "center", i.textBaseline = "middle", i.fillText(t.toFixed(1) + "°", 0, 0), i.font = 20 * e + "px Arial", i.fillText("(".concat((180 - t).toFixed(1), ")"), 0, .08 * a.width), i.rotate(-Math.PI / 2), i.translate(15 * e - .39 * a.width, 0), i.rotate((t - 90) * Math.PI / 180), i.fillStyle = "rgba(255,255,255,.4)", i.beginPath();
        var o = .75 * a.width,
          s = .026 * a.width;
        i.arc(o, 0, s, 0, 2 * Math.PI), i.fill(), i.stroke(), i.lineWidth = 1 * e, i.moveTo(0, 0), i.lineTo(o - s, 0), i.moveTo(o + s, 0), i.lineTo(.8 * a.width, 0), i.stroke(), i.rotate(-(t - 90) * Math.PI / 180), i.translate(-15 * e, .45 * -a.height), i.save();
      },
      drawProtractor: function drawProtractor(t, e) {
        var a = this.win.pixelRatio,
          i = 15 * a,
          o = .45 * e.height,
          s = .7 * e.width;
        t.clearRect(0, 0, e.height, e.height), t.save(), t.fillStyle = "rgba(255,255,255,.4)", t.strokeStyle = "#000", t.lineWidth = 1 * a, t.beginPath(), t.arc(i, o, s, 1.5 * Math.PI, .5 * Math.PI), t.closePath(), t.fill(), t.stroke(), t.translate(i, o), t.rotate(-Math.PI / 2 + Math.PI / 180);
        for (var h = 0; h < 179; h++) {
          t.beginPath(), t.moveTo(s, 0);
          var _e = (h + 1) % 5 != 0 ? 9 : (h + 1) % 10 != 0 ? 13 : 18;
          t.lineTo(s - _e * a, 0), t.stroke(), t.rotate(Math.PI / 180);
        }
        t.rotate(-Math.PI), t.font = "bold ".concat(12 * a, "px Arial"), t.fillStyle = "#000", t.textAlign = "center", t.textBaseline = "middle";
        for (var _h = 1; _h < 18; _h++) t.rotate(Math.PI / 18), t.save(), t.translate(s - 23 * a, 0), t.rotate(Math.PI / 2), t.fillText(10 * _h, 0, 5 * a), t.restore();
        t.beginPath(), t.arc(0, 0, 6 * a, 0, 2 * Math.PI), t.closePath(), t.fill();
      },
      calculateAngle: function calculateAngle(t, e) {
        var a = Math.abs(t);
        var i = Math.sqrt(a * a + e * e),
          o = Math.asin(e / i);
        return o = 180 * o / Math.PI, t > 0 ? o : 180 - o;
      }
    }, "calculateAngle", function calculateAngle(t) {
      var _t$touches$ = t.touches[0],
        e = _t$touches$.pageX,
        a = _t$touches$.pageY,
        _this$win = this.win,
        i = _this$win.windowHeight,
        o = _this$win.pixelRatio,
        s = .45 * i - a,
        h = Math.abs(e - 8),
        n = Math.abs(s);
      var r = Math.sqrt(n * n + h * h),
        l = Math.asin(h / r);
      return l = 180 * l / Math.PI, s > 0 ? l : 180 - l;
    }), "touchStart", function touchStart(t) {
      this.startAngle = this.calculateAngle(t);
    }), "touchMove", function touchMove(t) {
      var e = this.calculateAngle(t),
        a = e - this.startAngle;
      this.startAngle = e;
      var i = a + this.angle;
      i > 180 && (i = 180), i < 0 && (i = 0), this.angle = i, this.drawRocker(this.angle);
    }), "angleRound", function angleRound() {
      this.angle = Math.round(this.angle), this.drawRocker(this.angle);
    }), "openCamera", function openCamera(e) {
      var _this = this;
      if (this.isLock) return this.src = "", void (this.isLock = !1);
      t.index.getSetting().then(function (e) {
        e.authSetting["scope.camera"] || t.index.showModal({
          title: "温馨提醒",
          showCancel: !1,
          content: "请授权开启摄像头权限",
          confirmText: "去设置",
          success: function success(e) {
            e.confirm && t.index.openSetting();
          }
        }), _this.isOpenCamera = !_this.isOpenCamera;
      });
    }), "takePhoto", function takePhoto() {
      var _this2 = this;
      if (this.isLock) return this.src = "", this.isOpenCamera = !0, void (this.isLock = !1);
      this.isLock = !0, console.log("锁定画面"), this.photoCtx.takePhoto({
        quality: "high"
      }).then(function (t) {
        console.log(t.tempImagePath), _this2.src = t.tempImagePath, _this2.isOpenCamera = !1;
      });
    }), "error", function error(t) {
      console.log("错误", t);
    }),
    onShareAppMessage: function onShareAppMessage() {
      return {
        title: "量角器",
        path: "/pages/protractor/protractor"
      };
    }
  };var a = t._export_sfc(e, [["render", function (e, a, i, o, s, h) {
  return t.e({
    a: h.bgSrc,
    b: t.s(s.canvasStyle),
    c: t.o(function () {
      return h.touchStart && h.touchStart.apply(h, arguments);
    }),
    d: t.o(function () {
      return h.touchMove && h.touchMove.apply(h, arguments);
    }),
    e: t.s(s.canvasStyle),
    f: t.o(function () {
      return h.angleRound && h.angleRound.apply(h, arguments);
    }),
    g: t.t(h.openCameraStr),
    h: t.o(function () {
      return h.openCamera && h.openCamera.apply(h, arguments);
    }),
    i: t.t(s.isLock ? "重拍" : "锁定"),
    j: s.isOpenCamera || s.isLock,
    k: t.o(function () {
      return h.takePhoto && h.takePhoto.apply(h, arguments);
    }),
    l: s.isOpenCamera
  }, s.isOpenCamera ? {
    m: t.s(s.canvasStyle)
  } : {});
}], ["__scopeId", "data-v-d21cb5fd"]]);e.__runtimeHooks = 2, wx.createPage(a);