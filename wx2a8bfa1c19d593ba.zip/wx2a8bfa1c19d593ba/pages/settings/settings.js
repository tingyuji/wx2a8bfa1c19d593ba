var e = require("../../common/vendor.js"),
  t = {
    data: function data() {
      return {
        userInfo: {},
        backgrounds: [{
          title: "默认",
          color: "#F2F2FA"
        }, {
          title: "格子",
          picUrl: "/static/bg/1.jpg"
        }, {
          title: "简约炫彩",
          picUrl: "/static/bg/2.jpg"
        }, {
          title: "小清新",
          picUrl: "/static/bg/3.jpg"
        }, {
          title: "沙滩",
          picUrl: "/static/bg/4.jpg"
        }],
        menu: [[{
          title: "vip会员权益",
          icon: "premium-quality",
          page: "memberEquity"
        }, {
          title: "特权兑换",
          icon: "gift-box",
          page: "redeemCode"
        }], [{
          title: "常见问题",
          icon: "ellipsis",
          page: "commonProblem"
        }, {
          title: "联系客服",
          icon: "messenger",
          page: ""
        }], [{
          title: "分享小程序",
          icon: "send",
          page: ""
        }, {
          title: "关于掌机工具",
          icon: "info",
          page: "about"
        }]]
      };
    },
    methods: {},
    components: {
      topNav: function topNav() {
        return "../../components/top-nav.js";
      },
      myAd: function myAd() {
        return "../../components/my-ad.js";
      }
    }
  };if (!Array) {
  (e.resolveComponent("top-nav") + e.resolveComponent("my-ad"))();
}var o = e._export_sfc(t, [["render", function (t, o, n, a, c, i) {
  return {
    a: e.p({
      title: "设置"
    }),
    b: c.userInfo.avatar || "/static/user.png",
    c: c.userInfo.avatar ? "" : 1,
    d: e.o(function () {
      return t.setUserInfo && t.setUserInfo.apply(t, arguments);
    }),
    e: e.t(c.userInfo.name || "微信用户"),
    f: e.o(function (e) {
      return t.goPage("backend");
    }),
    g: e.f(c.backgrounds, function (o, n, a) {
      return e.e({
        a: o.color
      }, o.color ? {
        b: o.color
      } : {
        c: o.picUrl
      }, {
        d: e.t(o.title),
        e: e.o(function (e) {
          return t.setBackground(o.color, o.picUrl);
        }, n),
        f: n
      });
    }),
    h: e.f(c.menu, function (o, n, a) {
      return {
        a: e.f(o, function (o, a, c) {
          return {
            a: "/static/" + o.icon + ".png",
            b: e.t(o.title),
            c: e.o(function (e) {
              return o.func || t.goPage(o.page);
            }, a),
            d: 1 === n && 1 === a ? "contact" : 2 === n && 0 === a ? "share" : "",
            e: a
          };
        }),
        b: n
      };
    })
  };
}], ["__scopeId", "data-v-8d3afce5"]]);wx.createPage(o);