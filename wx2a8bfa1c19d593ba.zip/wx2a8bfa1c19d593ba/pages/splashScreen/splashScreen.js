var s = require("../../common/vendor.js"),
  e = {
    data: function data() {
      return {
        show: !1
      };
    },
    methods: {
      showBnt: function showBnt() {
        this.show = !this.show;
      },
      goBack: function goBack() {
        s.index.navigateBack();
      }
    },
    onShareAppMessage: function onShareAppMessage() {
      return {
        title: "氛围屏",
        path: "/pages/splashScreen/splashScreen"
      };
    }
  };var o = s._export_sfc(e, [["render", function (e, o, t, a, n, h) {
  return {
    a: n.show,
    b: s.o(function () {
      return h.goBack && h.goBack.apply(h, arguments);
    }),
    c: n.show ? 1 : "",
    d: s.o(function () {
      return h.showBnt && h.showBnt.apply(h, arguments);
    })
  };
}]]);e.__runtimeHooks = 2, wx.createPage(o);