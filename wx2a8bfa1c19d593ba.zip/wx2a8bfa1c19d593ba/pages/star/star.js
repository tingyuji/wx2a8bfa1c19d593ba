var o = require("../../common/vendor.js"),
  e = require("../../common/assets.js"),
  t = {
    data: function data() {
      return {};
    },
    onShow: function onShow() {
      this.$refs.goBack._setKeepScreenOn();
    },
    onUnload: function onUnload() {
      this.$refs.goBack._setKeepScreenOn(!1);
    },
    methods: {
      showButton: function showButton() {
        this.$refs.goBack._showButton();
      }
    },
    components: {
      goBack: function goBack() {
        return "../../components/go-back.js";
      }
    },
    onShareAppMessage: function onShareAppMessage() {
      return {
        title: "满屏红旗",
        path: "/pages/star/star"
      };
    }
  };if (!Array) {
  o.resolveComponent("go-back")();
}var s = o._export_sfc(t, [["render", function (t, s, a, n, r, c) {
  return {
    a: o.sr("goBack", "0f4a7b0a-0"),
    b: e._imports_0$1,
    c: o.f(4, function (o, e, t) {
      return {
        a: "rotate(".concat(25 + 45 * e, "deg)"),
        b: e
      };
    }),
    d: e._imports_0$1,
    e: o.o(function () {
      return c.showButton && c.showButton.apply(c, arguments);
    })
  };
}], ["__scopeId", "data-v-0f4a7b0a"]]);t.__runtimeHooks = 2, wx.createPage(s);