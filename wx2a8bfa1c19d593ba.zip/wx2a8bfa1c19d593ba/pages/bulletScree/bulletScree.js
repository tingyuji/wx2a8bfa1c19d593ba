require("../../@babel/runtime/helpers/Arrayincludes");var _slicedToArray2 = require("../../@babel/runtime/helpers/slicedToArray");var e = require("../../common/vendor.js"),
  t = {
    data: function data() {
      return {
        scorllAnimation: {},
        animationTextStyle: {},
        win: {},
        duration: 0,
        translate: 0,
        cacheKey: "BULLET_SCREE",
        speed: 1,
        color: "white",
        fontSize: 300,
        fontFamily: "PingFang SC",
        background: "black",
        classNames: [],
        text: '"你还记得她吗？"  "早忘了，哈哈"  "我还没说是谁。"',
        screenBrightness: 0
      };
    },
    onLoad: function onLoad() {
      var _this = this;
      this.getConfig();
      var _this$$appSystemInfo$ = this.$appSystemInfo.screenInfo,
        t = _this$$appSystemInfo$.windowWidth,
        n = _this$$appSystemInfo$.screenHeight,
        i = _this$$appSystemInfo$.pixelRatio;
      this.win = {
        windowWidth: t,
        screenHeight: n,
        pixelRatio: i
      }, e.index.getScreenBrightness().then(function (e) {
        _this.screenBrightness = e.value;
      }), this.animation = e.index.createAnimation({
        timingFunction: "linear"
      });
    },
    onShow: function onShow() {
      this.animationFunc(), this._setKeepScreenOn();
    },
    onUnload: function onUnload() {
      clearTimeout(this.timer), e.index.setScreenBrightness({
        value: this.screenBrightness
      }), this._setKeepScreenOn(!1);
    },
    methods: {
      onDrawer: function onDrawer() {
        this.$refs.mainMeun.mainMeunClick(), this.$refs.styleMeun.styleMeunClick(!1);
      },
      animationFunc: function animationFunc() {
        var _this2 = this;
        this.$nextTick(function () {
          clearTimeout(_this2.timer);
          var t = _this2.win.screenHeight;
          _this2.animation.translate(t).step({
            duration: 0
          }), _this2.scorllAnimation = _this2.animation.export(), e.index.createSelectorQuery().select(".animation").boundingClientRect().exec(function (e) {
            var _e = _slicedToArray2(e, 1),
              n = _e[0].height,
              i = n / t;
            _this2.translate = n, _this2.duration = 5e3 * (i < 1 ? 1 : i) / _this2.speed;
            var s = function s() {
              _this2.animation.translate(-_this2.translate).step({
                duration: _this2.duration
              }), _this2.scorllAnimation = _this2.animation.export(), _this2.timer = setTimeout(function () {
                _this2.animation.translate(t).step({
                  duration: 0,
                  timingFunction: "step-start"
                }), _this2.scorllAnimation = _this2.animation.export(), _this2.$nextTick(function () {
                  s();
                });
              }, _this2.duration);
            };
            s();
          });
        });
      },
      sendText: function sendText(e) {
        this.text = e, this.animationFunc(), this.setConfig();
      },
      openStyleSettings: function openStyleSettings() {
        this.$refs.styleMeun.styleMeunClick();
      },
      setTextStyle: function setTextStyle(t, n) {
        this[t] = n;
        ["fontFamily", "speed", "fontSize"].includes(t) && this.animationFunc(), "classNames" == t && e.index.setScreenBrightness({
          value: n.includes("light") ? 1 : this.screenBrightness
        }), this.setConfig();
      },
      _setKeepScreenOn: function _setKeepScreenOn() {
        var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : !0;
        t && e.index.showToast({
          title: "已开启常亮",
          icon: "none"
        }), e.index.setKeepScreenOn({
          keepScreenOn: t
        });
      },
      getConfig: function getConfig() {
        var t = e.index.getStorageSync(this.cacheKey) || {
          color: "white",
          fontSize: 300,
          fontFamily: "PingFang SC",
          background: "black",
          classNames: [],
          text: '"你还记得她吗？"  "早忘了，哈哈"  "我还没说是谁。"'
        };
        for (var _e2 in t) this[_e2] = t[_e2];
      },
      setConfig: function setConfig() {
        var t = {
          color: this.color,
          fontSize: this.fontSize,
          fontFamily: this.fontFamily,
          background: this.background,
          classNames: this.classNames,
          text: this.text
        };
        e.index.setStorageSync(this.cacheKey, t);
      }
    },
    components: {
      bulletMainMeun: function bulletMainMeun() {
        return "../../components/bullet-main-meun.js";
      },
      bulletStyleMeun: function bulletStyleMeun() {
        return "../../components/bullet-style-meun.js";
      }
    },
    onShareAppMessage: function onShareAppMessage() {
      return {
        title: "手持弹幕",
        path: "/pages/bulletScree/bulletScree"
      };
    }
  };if (!Array) {
  (e.resolveComponent("bullet-main-meun") + e.resolveComponent("bullet-style-meun"))();
}var n = e._export_sfc(t, [["render", function (t, n, i, s, o, a) {
  return {
    a: e.t(o.text),
    b: o.scorllAnimation,
    c: e.n(o.classNames),
    d: o.color,
    e: o.fontSize + "rpx",
    f: o.fontFamily,
    g: o.win.windowWidth + "px",
    h: e.o(function () {
      return a.onDrawer && a.onDrawer.apply(a, arguments);
    }),
    i: o.background,
    j: e.sr("mainMeun", "00ffd79c-0"),
    k: e.o(a.sendText),
    l: e.o(a.openStyleSettings),
    m: e.sr("styleMeun", "00ffd79c-1"),
    n: e.o(a.setTextStyle),
    o: e.p({
      speed: o.speed,
      color: o.color,
      fontSize: o.fontSize,
      fontFamily: o.fontFamily,
      background: o.background,
      classNames: o.classNames
    })
  };
}], ["__scopeId", "data-v-00ffd79c"]]);t.__runtimeHooks = 2, wx.createPage(n);