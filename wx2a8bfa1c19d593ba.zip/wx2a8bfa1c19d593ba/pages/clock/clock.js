var e = require("../../common/vendor.js"),
  t = {
    data: function data() {
      return {
        list: ["这个世界上的机会从来都不是平等的，但是你努力争取了就一定会有。", "心若有所期，我便是你的温室，亦可做你的堡垒。你若近我一分，我包揽你万千。", "被窝是天堂在人间设的分店", "我想你了，我没喝酒!", "你要是在我身边就好了，这句话并不是在怪你，而是这一瞬间我比任何时候都想你。", "你是经历了多少委屈，才有了那一身好脾气。", "“你还记得她吗？” “早忘了，哈哈” “我还没说是谁。”", "你问我为何沉默，有的人无话可说，有的话无人可说", "人不是因为没有信念而失败，而是因为不能把信念化成行动，并且坚持到底。", "所有的努力 不是为了让别人觉得你了不起 而是让自己过得充实而有追求", "在成长的岁月里，要慢慢地学会微笑着释然。", "那年，风很轻，阳光很暖，岁月很长。此时、彼时，阳光微淡，岁月静好，安然若素。", "我比任何人都爱你，但这八个字毫无意义。", "真正要走的人连个招呼都不屑打。反而是那些说‘我走了’的人，不过是等你一句‘别走’", "后来我发现世界其实真的很大，没有刻意地见面，就真的没有见过了", "如果你提前知道，这一生是这样的，你还会来吗？"],
        text: ""
      };
    },
    onLoad: function onLoad() {
      this.$refs.flipClock.updata(), this.updateDesc();
    },
    onShow: function onShow() {
      this.$refs.goBack._setKeepScreenOn();
    },
    onUnload: function onUnload() {
      this.$refs.goBack._setKeepScreenOn(!1), this.$refs.flipClock.clearUpdata();
    },
    methods: {
      showButton: function showButton() {
        this.$refs.goBack._showButton();
      },
      updateDesc: function updateDesc() {
        this.text = this.list[Math.floor(Math.random() * this.list.length)];
      }
    },
    components: {
      goBack: function goBack() {
        return "../../components/go-back.js";
      },
      flipClock: function flipClock() {
        return "../../components/flip-clock.js";
      }
    },
    onShareAppMessage: function onShareAppMessage() {
      return {
        title: "翻页时钟",
        path: "/pages/clock/clock"
      };
    }
  };if (!Array) {
  (e.resolveComponent("go-back") + e.resolveComponent("flip-clock"))();
}var o = e._export_sfc(t, [["render", function (t, o, s, c, a, n) {
  return {
    a: e.sr("goBack", "dc0fb60a-0"),
    b: e.sr("flipClock", "dc0fb60a-1"),
    c: e.p({
      theme: "clock-theme"
    }),
    d: e.t(a.text),
    e: e.o(function () {
      return n.updateDesc && n.updateDesc.apply(n, arguments);
    }),
    f: e.o(function () {
      return n.showButton && n.showButton.apply(n, arguments);
    })
  };
}], ["__scopeId", "data-v-dc0fb60a"]]);t.__runtimeHooks = 2, wx.createPage(o);