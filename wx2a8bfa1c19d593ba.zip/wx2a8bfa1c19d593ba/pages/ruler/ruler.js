var t = require("../../common/vendor.js"),
  e = require("../../common/assets.js"),
  i = {
    data: function data() {
      return {
        cacheKey: "RULER_DATA",
        win: {},
        isCalibration: !1,
        defaultValue: 5.4,
        scaleValue: 0,
        scale_0_top: 10,
        buttonTop: 200,
        scaleRatio: 5,
        dpr: 0
      };
    },
    onLoad: function onLoad() {
      var _this$$appSystemInfo$ = this.$appSystemInfo.screenInfo,
        t = _this$$appSystemInfo$.windowHeight,
        e = _this$$appSystemInfo$.windowWidth,
        i = _this$$appSystemInfo$.pixelRatio;
      this.win = {
        windowWidth: e,
        windowHeight: t,
        dpr: i
      }, this.checkCache();
    },
    mounted: function mounted() {
      t.index.createSelectorQuery().select("#canvas").fields({
        node: !0,
        size: !0
      }).exec(this.init.bind(this));
    },
    computed: {
      bgnumStyle: function bgnumStyle() {
        return {
          height: "".concat(this.buttonTop, "px"),
          backgroundColor: "var(".concat(this.isCalibration ? "--red" : "--bule", ")")
        };
      },
      canvasStyle: function canvasStyle() {
        return {
          width: "100%",
          height: "100%"
        };
      }
    },
    methods: {
      init: function init(t) {
        var _t$ = t[0],
          e = _t$.width,
          i = _t$.height,
          s = _t$.node,
          a = s.getContext("2d"),
          o = this.win.dpr;
        s.width = e * o, s.height = i * o, this.canvas = s, this.ctx = a, this.drawRuler();
      },
      drawRuler: function drawRuler() {
        var _this$canvas = this.canvas,
          t = _this$canvas.width,
          e = _this$canvas.height,
          i = this.ctx,
          s = this.win.dpr,
          a = this.isCalibration,
          o = this.scaleRatio * s,
          n = t,
          c = s * this.scale_0_top,
          h = 22 * s,
          l = 20 * s,
          r = 12 * s;
        if (i.clearRect(0, 0, t, e), i.save(), a) return;
        var u = ~~(e / o / 10) - 1;
        i.strokeStyle = "#000", i.lineWidth = s;
        for (var d = 0; d < 10 * u + 1; d++) {
          i.beginPath(), i.moveTo(n, c + d * o);
          var _t = d % 5 != 0 ? r : d % 10 != 0 ? l : h;
          i.lineTo(n - _t, c + d * o), i.stroke();
        }
        i.rotate(Math.PI / 2), i.font = 20 * s + "px Arial", i.fillStyle = "#000", i.textAlign = "center", i.textBaseline = "middle";
        for (var _d = 0; _d < u + 1; _d++) i.save(), i.fillText(_d, c + _d * o * 10, -n + h + 15 * s), i.restore();
        i.rotate(-Math.PI / 2);
      },
      calibrationScale: function calibrationScale() {
        this.isCalibration && (this.scaleRatio = this.buttonTop / (10 * this.defaultValue), this.scaleValue = this.defaultValue, this.buttonTop = this.buttonTop + this.scale_0_top, t.index.setStorageSync(this.cacheKey, {
          scaleRatio: this.scaleRatio,
          scaleValue: this.scaleValue,
          buttonTop: this.buttonTop
        })), this.isCalibration = !this.isCalibration, this.drawRuler();
      },
      checkCache: function checkCache() {
        var e = t.index.getStorageSync(this.cacheKey);
        if (e) {
          var _t2 = e.scaleRatio,
            _i = e.buttonTop,
            _s = e.scaleValue;
          this.scaleRatio = _t2, this.buttonTop = _i, this.scaleValue = _s;
        } else this.isCalibration = !0, t.index.showModal({
          title: "温馨提醒",
          content: "首次使用直尺工具需手动校准",
          showCancel: !1,
          confirmText: "知道了",
          success: function success(t) {}
        });
      },
      touchStart: function touchStart(t) {
        this.startY = t.touches[0].pageY;
      },
      touchMove: function touchMove(t) {
        var e = t.touches[0].pageY,
          i = e - this.startY;
        this.startY = e;
        var s = this.buttonTop + i;
        var a = this.scale_0_top;
        s <= a && (s = a);
        var o = .85 * this.win.windowHeight;
        if (s >= o && (s = o), this.buttonTop = s, !this.isCalibration) {
          var _t3 = s - this.scale_0_top;
          this.scaleValue = (_t3 / this.scaleRatio / 10).toFixed(2);
        }
      }
    },
    onShareAppMessage: function onShareAppMessage() {
      return {
        title: "直尺",
        path: "/pages/rule/rule"
      };
    }
  };var s = t._export_sfc(i, [["render", function (i, s, a, o, n, c) {
  return {
    a: e._imports_0,
    b: n.buttonTop + "px",
    c: t.s(c.bgnumStyle),
    d: t.t(n.isCalibration ? "确定" : "校准"),
    e: t.o(function () {
      return c.calibrationScale && c.calibrationScale.apply(c, arguments);
    }),
    f: n.isCalibration,
    g: t.t(n.isCalibration ? n.defaultValue : n.scaleValue),
    h: t.s(c.canvasStyle),
    i: t.o(function () {
      return c.touchStart && c.touchStart.apply(c, arguments);
    }),
    j: t.o(function () {
      return c.touchMove && c.touchMove.apply(c, arguments);
    })
  };
}], ["__scopeId", "data-v-5cc0a08a"]]);i.__runtimeHooks = 2, wx.createPage(s);