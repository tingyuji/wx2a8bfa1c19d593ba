var e = require("../../common/vendor.js"),
  o = {
    data: function data() {
      return {};
    },
    methods: {},
    components: {
      topNav: function topNav() {
        return "../../components/top-nav.js";
      }
    }
  };if (!Array) {
  e.resolveComponent("top-nav")();
}var t = e._export_sfc(o, [["render", function (o, t, n, r, s, a) {
  return {
    a: e.p({
      title: "去水印"
    })
  };
}]]);wx.createPage(t);