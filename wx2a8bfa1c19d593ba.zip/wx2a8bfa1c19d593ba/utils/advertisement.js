var o = require("../common/vendor.js");var e = null;var t = {
  load: function load() {
    var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "adunit-f7b102f936d2f4b7";
    o.index.createInterstitialAd && ((e = o.index.createInterstitialAd({
      adUnitId: t
    })).onLoad(function () {
      console.log("插屏广告加载中");
    }), e.onError(function (o) {
      console.log("加载错误", o);
    }), e.onClose(function (o) {
      console.log("插屏广告关闭", o);
    }));
  },
  show: function show() {
    setTimeout(function () {
      e && e.show().catch(function (o) {
        console.error(o);
      });
    }, 500);
  }
};exports.interstitial = t;