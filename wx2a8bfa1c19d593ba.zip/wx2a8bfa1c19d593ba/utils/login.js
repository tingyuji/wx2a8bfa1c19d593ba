var _regeneratorRuntime2 = require("../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../@babel/runtime/helpers/asyncToGenerator");var e = require("../common/vendor.js"),
  r = require("../api/v1/index.js");exports.login = /*#__PURE__*/_asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
  var _yield$e$wx$1$login, n, _yield$r$loginApi, o, s, t;
  return _regeneratorRuntime2().wrap(function _callee$(_context) {
    while (1) switch (_context.prev = _context.next) {
      case 0:
        _context.prev = 0;
        _context.next = 3;
        return e.wx$1.login();
      case 3:
        _yield$e$wx$1$login = _context.sent;
        n = _yield$e$wx$1$login.code;
        _context.next = 7;
        return r.loginApi(n);
      case 7:
        _yield$r$loginApi = _context.sent;
        o = _yield$r$loginApi.user;
        s = _yield$r$loginApi.accessToken;
        t = _yield$r$loginApi.refreshToken;
        return _context.abrupt("return", (e.index.setStorageSync("accessToken", "Bearer ".concat(s)), e.index.setStorageSync("refreshToken", t), o));
      case 14:
        _context.prev = 14;
        _context.t0 = _context["catch"](0);
        e.index.showToast({
          title: "登录失败，请稍后重试",
          icon: "error",
          duration: 2e3
        });
      case 17:
      case "end":
        return _context.stop();
    }
  }, _callee, null, [[0, 14]]);
}));