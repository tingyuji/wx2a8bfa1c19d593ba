exports.checkSign = function (t, c) {
  return (t >> 1).toString(16).slice(2) == c;
};