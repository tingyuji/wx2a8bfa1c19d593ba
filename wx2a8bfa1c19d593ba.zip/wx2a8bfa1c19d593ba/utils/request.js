var _objectSpread2 = require("../@babel/runtime/helpers/objectSpread2");var e = require("../common/vendor.js"),
  s = require("../api/config.js");exports.request = function (t) {
  var o = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "GET";
  var a = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var r = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : !1;
  var n = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : null;
  var _ref = n || {},
    _ref$contentType = _ref.contentType,
    i = _ref$contentType === void 0 ? "application/json" : _ref$contentType;
  if (-1 === t.indexOf(s.baseUrl) && (t = s.baseUrl + t), "GET" === o && 0 != Object.keys(a).length) {
    t = "".concat(t, "?").concat(Object.keys(a).map(function (e) {
      return "".concat(e, "=").concat(a[e]);
    }).join("&"));
  }
  var c = {
    url: t,
    method: o,
    header: {
      "Content-Type": i
    },
    data: "GET" === o ? {} : a
  };
  if (r) {
    var _s = e.index.getStorageSync("accessToken");
    if (!_s) return void e.index.showToast({
      title: "请登录",
      icon: "error",
      duration: 2e3
    });
    c.header.Authorization = _s;
  }
  return new Promise(function (t, o) {
    e.index.request(_objectSpread2(_objectSpread2({}, c), {}, {
      success: function success(a) {
        switch (a.statusCode) {
          case s.statusCode.SUCCESS:
            return t(_objectSpread2(_objectSpread2({}, a.data), {}, {
              code: a.statusCode
            }));
          case s.statusCode.AUTHENTICATE:
            return t({
              message: "token失效，请重新输入"
            });
          case s.statusCode.FORBIDDEN:
            return o({
              message: "没有权限访问"
            });
          case s.statusCode.NOT_FOUND:
            return o({
              message: "请求资源不存在"
            });
          case s.statusCode.SERVER_ERROR:
            return "Failed to refresh token" === a.data.message ? (e.index.setStorageSync("profile", null), e.index.showToast({
              title: "请登录",
              icon: "error",
              duration: 2e3
            }), o({
              message: "请重新登录"
            })) : o({
              message: "服务器错误"
            });
          case s.statusCode.BAD_GATEWAY:
            return o({
              message: "服务端出现了问题"
            });
        }
      },
      fail: function fail(e) {
        console.log("网络请求异常", e, c), o(e);
      }
    }));
  });
};