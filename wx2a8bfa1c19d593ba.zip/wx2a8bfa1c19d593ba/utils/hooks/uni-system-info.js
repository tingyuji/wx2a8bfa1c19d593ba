var e = require("../../common/vendor.js");exports.uniSystemInfo = function () {
  var i = {
      height: 0
    },
    n = e.index.getMenuButtonBoundingClientRect(),
    t = {
      pixelRatio: 0,
      windowWidth: 0,
      windowHeight: 0,
      screenHeight: 0
    },
    _e$index$getWindowInf = e.index.getWindowInfo(),
    o = _e$index$getWindowInf.pixelRatio,
    d = _e$index$getWindowInf.windowWidth,
    h = _e$index$getWindowInf.windowHeight,
    r = _e$index$getWindowInf.statusBarHeight,
    g = _e$index$getWindowInf.screenHeight;
  return i.height = r + 44, t.pixelRatio = o, t.windowWidth = d, t.windowHeight = h, t.screenHeight = g, {
    navBarInfo: i,
    screenInfo: t,
    navBarBoundingInfo: n
  };
};